package hook

// Check is a named function type.
type Check func(name string) error

// Server calls the functions its fields hold.
type Server struct {
	Name    string
	OnError func(msg string)
	Check   Check
}

// Run calls Check with the name, and OnError with a failure's text.
func (s *Server) Run() string {
	if s.Check == nil {
		return "no check"
	}
	if err := s.Check(s.Name); err != nil {
		if s.OnError != nil {
			s.OnError(err.Error())
		}
		return "failed: " + err.Error()
	}
	return "ok"
}

// Logf is a function variable.
var Logf func(format string) int

// Log calls Logf, or returns -1 when it is not set.
func Log(s string) int {
	if Logf == nil {
		return -1
	}
	return Logf(s)
}
