// Package fnopt takes functional options, as AWS SDK v2's clients do
// (optFns ...func(*s3.Options)).
package fnopt

import "errors"

// Options are what an option changes.
type Options struct {
	Name    string
	Retries int
}

// Option is a named option function type.
type Option func(*Options)

// Describe applies the options to the defaults in order and describes the result.
func Describe(base string, optFns ...func(*Options)) string {
	o := Options{Name: base, Retries: 1}
	for _, f := range optFns {
		f(&o)
	}
	return o.Name + " retries=" + itoa(o.Retries)
}

// Count applies named options and returns how many there were.
func Count(opts ...Option) int {
	o := Options{}
	for _, f := range opts {
		f(&o)
	}
	return len(opts) + o.Retries
}

// Check applies options that may fail, stopping at the first error.
func Check(fns ...func(*Options) error) error {
	o := Options{}
	for _, f := range fns {
		if err := f(&o); err != nil {
			return errors.New("option: " + err.Error())
		}
	}
	return nil
}

func itoa(n int) string {
	if n == 0 {
		return "0"
	}
	s := ""
	for ; n > 0; n /= 10 {
		s = string(rune('0'+n%10)) + s
	}
	return s
}
