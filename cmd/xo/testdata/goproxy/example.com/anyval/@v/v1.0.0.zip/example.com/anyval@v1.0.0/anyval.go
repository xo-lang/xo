// Package anyval is a test module: functions that return Go's any with
// no handle in their signatures, so a recording records them (decision 0412).
package anyval

// Answer returns 42 as an any.
func Answer() any { return 42 }

// Pair returns its two arguments as a []any.
func Pair(a, b any) []any { return []any{a, b} }
