package multi

import (
	"strconv"
	"strings"
)

// Collect calls next until its bool is false and joins what it gave.
func Collect(next func(i int) (string, bool)) string {
	var b []string
	for i := 0; ; i++ {
		s, ok := next(i)
		if !ok {
			return strings.Join(b, ",")
		}
		b = append(b, s)
	}
}

// Try calls f and reports its two results, or its error.
func Try(f func() (int, string, error)) string {
	n, s, err := f()
	if err != nil {
		return "error: " + err.Error()
	}
	return strconv.Itoa(n) + " " + s
}

// Splitter returns a function that cuts s at sep.
func Splitter(sep string) func(s string) (string, string, bool) {
	return func(s string) (string, string, bool) { return strings.Cut(s, sep) }
}
