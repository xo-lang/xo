// Package iface defines an interface and a function that takes it.
package iface

// Greeter says hello.
type Greeter interface {
	Greet() string
}

// Say is g's greeting with a mark.
func Say(g Greeter) string { return g.Greet() + "!" }
