// Package impl implements iface.Greeter without naming it in any
// exported signature (decision 0416 addendum, widened 2026-10-30).
package impl

import "example.com/upwide/iface"

var _ iface.Greeter = (*Hello)(nil)

// Hello greets a name.
type Hello struct{ name string }

// New is a Hello for name.
func New(name string) *Hello { return &Hello{name: name} }

// Greet is the greeting.
func (h *Hello) Greet() string { return "hello " + h.name }
