package chans

import "errors"

// Ticks sends 0 to n-1 and closes the channel.
func Ticks(n int) <-chan int {
	c := make(chan int)
	go func() {
		for i := 0; i < n; i++ {
			c <- i
		}
		close(c)
	}()
	return c
}

// Watcher reports names and errors on its channels.
type Watcher struct {
	Names  chan string
	Errors chan error
}

// NewWatcher returns a watcher with buffered channels.
func NewWatcher() *Watcher {
	return &Watcher{Names: make(chan string, 4), Errors: make(chan error, 4)}
}

// Emit sends a name, or an error for an empty one.
func (w *Watcher) Emit(name string) {
	if name == "" {
		w.Errors <- errors.New("empty name")
		return
	}
	w.Names <- name
}

// Close closes both channels.
func (w *Watcher) Close() {
	close(w.Names)
	close(w.Errors)
}

// Never returns a channel nothing is ever sent on.
func Never() <-chan int { return make(chan int) }
