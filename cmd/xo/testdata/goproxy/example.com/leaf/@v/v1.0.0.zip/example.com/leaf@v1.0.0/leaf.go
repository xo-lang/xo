// Package leaf is a test module: example.com/top imports it, so a
// main module that requires top needs leaf as an indirect requirement.
package leaf

// Twice returns 2n.
func Twice(n int) int { return 2 * n }
