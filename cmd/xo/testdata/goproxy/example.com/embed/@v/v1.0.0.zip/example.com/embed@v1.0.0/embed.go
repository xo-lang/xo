// Package embed is a synthetic module for xo's use go tests of embedded
// struct fields (decision 0491 A).
package embed

// Entry is embedded by value in LoggedEntry, as zapcore.Entry is in
// zap's observer.LoggedEntry.
type Entry struct {
	Level   int
	Message string
}

// LoggedEntry embeds Entry by value.
type LoggedEntry struct {
	Entry
	Context []string
}

// Make returns a LoggedEntry with the message.
func Make(msg string) *LoggedEntry {
	return &LoggedEntry{Entry: Entry{Level: 2, Message: msg}}
}

// Message reads the entry's message through Go's selector.
func Message(le *LoggedEntry) string { return le.Message }

type inner struct {
	Depth2 string
}

// Mid embeds an unexported struct.
type Mid struct {
	inner
	Name string
}

// Outer reaches inner's Depth2 at depth two.
type Outer struct {
	Mid
	Tag string
}

// NewOuter returns an Outer with every field set.
func NewOuter() *Outer {
	return &Outer{Mid: Mid{inner: inner{Depth2: "deep"}, Name: "mid"}, Tag: "top"}
}

// A and B both have X.
type A struct{ X int }

// B has an X too.
type B struct{ X int }

// Amb embeds A and B: X is ambiguous, Y is its own.
type Amb struct {
	A
	B
	Y int
}

// Ptr embeds a pointer.
type Ptr struct {
	*Entry
	N int
}

// Namer is an interface.
type Namer interface{ Name() string }

// WithIface embeds an interface.
type WithIface struct {
	Namer
	K int
}
