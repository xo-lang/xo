// Package cberr is a test module of callbacks that return errors (decision 0416).
package cberr

import (
	"errors"
	"fmt"
)

// ErrStop is a sentinel error.
var ErrStop = errors.New("stop")

// Each calls f on 1..n and returns its first error, wrapped.
func Each(n int, f func(int) error) error {
	for i := 1; i <= n; i++ {
		if err := f(i); err != nil {
			return fmt.Errorf("at %d: %w", i, err)
		}
	}
	return nil
}

// Lengths maps f over xs and returns its first error, wrapped.
func Lengths(xs []string, f func(string) (int, error)) ([]int, error) {
	var out []int
	for _, x := range xs {
		n, err := f(x)
		if err != nil {
			return nil, fmt.Errorf("%q: %w", x, err)
		}
		out = append(out, n)
	}
	return out, nil
}

// Fail returns ErrStop.
func Fail() error { return ErrStop }

// IsStop reports whether f's error is ErrStop.
func IsStop(f func() error) bool { return errors.Is(f(), ErrStop) }
