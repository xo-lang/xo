package opt

import "strconv"

// Options has optional fields, a nil pointer meaning unset.
type Options struct {
	Name  *string
	Limit *int
	On    *bool
}

// Describe prints each field, or "-" when it is nil.
func Describe(o *Options) string {
	name, limit, on := "-", "-", "-"
	if o.Name != nil {
		name = *o.Name
	}
	if o.Limit != nil {
		limit = strconv.Itoa(*o.Limit)
	}
	if o.On != nil {
		on = strconv.FormatBool(*o.On)
	}
	return "name=" + name + " limit=" + limit + " on=" + on
}

// Or returns *x, or d when x is nil.
func Or(x *int, d int) int {
	if x == nil {
		return d
	}
	return *x
}

// Ptr returns a pointer to n.
func Ptr(n int) *int { return &n }

// Bump adds one to the limit in place; Xo sees it by reading the field again.
func (o *Options) Bump() {
	if o.Limit != nil {
		*o.Limit++
	}
}
