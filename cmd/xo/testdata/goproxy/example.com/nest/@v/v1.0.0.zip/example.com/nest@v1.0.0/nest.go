// Package nest is the enclosing module of example.com/nest/sub, a
// module of its own (as aws-sdk-go-v2 is of service/s3).
package nest

func One() int { return 1 }
