package sub

import "example.com/nest"

func Two() int { return nest.One() + 1 }
