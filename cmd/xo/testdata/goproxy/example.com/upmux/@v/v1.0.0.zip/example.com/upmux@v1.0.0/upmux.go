// Package upmux is a router whose *Mux implements net/http's Handler, as
// chi's does: Xo passes a Mux where Go takes an http.Handler.
package upmux

import (
	"io"
	"net/http"
	"net/http/httptest"
)

// Mux answers fixed text by path.
type Mux struct{ text map[string]string }

// New returns an empty Mux.
func New() *Mux { return &Mux{text: map[string]string{}} }

// Text answers body at path.
func (m *Mux) Text(path, body string) { m.text[path] = body }

// ServeHTTP makes *Mux an http.Handler.
func (m *Mux) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	b, ok := m.text[r.URL.Path]
	if !ok {
		http.NotFound(w, r)
		return
	}
	io.WriteString(w, b)
}

// Get serves one GET of path with h and returns the status and body.
func Get(h http.Handler, path string) string {
	rec := httptest.NewRecorder()
	h.ServeHTTP(rec, httptest.NewRequest("GET", path, nil))
	return http.StatusText(rec.Code) + ": " + rec.Body.String()
}
