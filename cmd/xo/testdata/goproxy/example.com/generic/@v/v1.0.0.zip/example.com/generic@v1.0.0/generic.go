// Package generic is a test module of generic functions (decision 0415).
package generic

import "cmp"

// Index is the index of v in s, or -1.
func Index[S ~[]E, E comparable](s S, v E) int {
	for i := range s {
		if s[i] == v {
			return i
		}
	}
	return -1
}

// Max is the larger of a and b.
func Max[T cmp.Ordered](a, b T) T { return max(a, b) }

// Keep returns v unchanged: any value passes through Go.
func Keep[T any](v T) T { return v }

// Zero is T's zero value.
func Zero[T any]() T {
	var z T
	return z
}

// Count is the number of entries of m.
func Count[M ~map[K]V, K comparable, V any](m M) int { return len(m) }
