// Package gentype is a test module of generic types (decision 0415).
package gentype

import "cmp"

// Box holds one value.
type Box[T any] struct {
	Val T
}

// NewBox is a Box of v.
func NewBox[T any](v T) *Box[T] { return &Box[T]{Val: v} }

// Get is the value.
func (b *Box[T]) Get() T { return b.Val }

// Set replaces the value.
func (b *Box[X]) Set(v X) { b.Val = v }

// Set is a set of comparable keys.
type Set[K comparable] struct{ m map[K]bool }

// NewSet is an empty Set.
func NewSet[K comparable]() *Set[K] { return &Set[K]{m: map[K]bool{}} }

// Add adds k.
func (s *Set[K]) Add(k K) { s.m[k] = true }

// Has reports whether k is in s.
func (s *Set[K]) Has(k K) bool { return s.m[k] }

// Len is the number of keys.
func (s *Set[K]) Len() int { return len(s.m) }

// Top keeps the largest value it is given.
type Top[T cmp.Ordered] struct {
	v   T
	set bool
}

// NewTop is an empty Top.
func NewTop[T cmp.Ordered]() *Top[T] { return &Top[T]{} }

// Offer keeps v when it is larger.
func (t *Top[T]) Offer(v T) {
	if !t.set || v > t.v {
		t.v, t.set = v, true
	}
}

// Max is the largest value offered, and whether any was.
func (t *Top[T]) Max() (T, bool) { return t.v, t.set }
