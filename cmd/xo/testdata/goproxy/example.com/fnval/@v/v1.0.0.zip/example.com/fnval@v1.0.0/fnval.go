package fnval

import (
	"errors"
	"strconv"
)

// Adder returns a function that adds n.
func Adder(n int) func(int) int { return func(x int) int { return x + n } }

// Parser returns a function that parses a decimal integer.
func Parser() func(string) (int, error) {
	return func(s string) (int, error) {
		n, err := strconv.Atoi(s)
		if err != nil {
			return 0, errors.New("not a number: " + s)
		}
		return n, nil
	}
}

// Hooks holds a function the caller sets and reads back.
type Hooks struct {
	OnEvent func(name string) string
}

// Fire calls OnEvent.
func (h *Hooks) Fire(name string) string { return h.OnEvent(name) }

// Nil returns a nil function; calling it panics.
func Nil() func() int { return nil }
