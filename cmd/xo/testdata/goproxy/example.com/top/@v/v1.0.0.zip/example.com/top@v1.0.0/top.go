// Package top is a test module that imports example.com/leaf.
package top

import "example.com/leaf"

// Quad returns 4n.
func Quad(n int) int { return leaf.Twice(leaf.Twice(n)) }
